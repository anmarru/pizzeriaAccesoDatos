package modelo.pedido;

public enum EstadoPedido {

    PENDIENTE,ENTREGADO, FINALIZADO, CANCELADO
}
